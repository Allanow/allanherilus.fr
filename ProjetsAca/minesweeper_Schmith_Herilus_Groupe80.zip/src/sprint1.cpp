//minesweeper
/*Biblioth�ques utilis�es*/
#include <stdio.h>
#include <cassert>
#include <cstdlib>
#include <random>
#include <iostream>
#include <sstream>
#include "struct.h"
#include <string>
using namespace std;


/* 
	@brief initialise un probl�me et affecte des positions de mines al�atoire
	@param[in] g: la grille
*/

void creer_probleme_random(Grille* g) {
	cin >> g->nb_lignes >> g->nb_colonne >> g->nb_mines;
	int taille = g->nb_colonne * g->nb_lignes;
	g->tab = new Case * [taille];
	g->position_mines = new int[g->nb_mines];
		
	//creer la struct de base des cases
	for (int i = 0; i < g->nb_lignes * g->nb_colonne; i++) {
		g->tab[i] = new Case;
		g->tab[i]->mine = 0;
		g->tab[i]->nbmineautour = 0;		
		char etat[] = " ";
	}

	/* initialise random */
	srand(time(NULL));

	for (int i = 0; i < g->nb_mines; i++) {
		int pos_mine = rand() % (g->nb_colonne * g->nb_lignes - 1);
		
		if (g->tab[pos_mine]->mine == 0) {
			g->tab[pos_mine]->mine = 1;
			g->position_mines[i] = pos_mine;

		}
		else if (g->tab[pos_mine]->mine == 1) // condition permettant de recommencer un tirage  
			i--;							  // si on obtient al�atoirement plusieurs fois 	
	}										  // la m�me position de mine
}

/*	
	@brief Initialise un probl�me avec la position des mines entr� par l'utilisateur
	@param[int] g: la grille
*/

void creer_probleme_util(Grille* g) {
	cin >> g->nb_lignes >> g->nb_colonne >> g->nb_mines;
	int taille = g->nb_colonne * g->nb_lignes;
	g->tab = new Case * [taille];
	g->position_mines = new int[g->nb_mines];

	//creer la struct de base des cases
	for (int i = 0; i < g->nb_lignes * g->nb_colonne; i++) {
		g->tab[i] = new Case;
		g->tab[i]->contenu = ' ';
		g->tab[i]->mine = 0;
		g->tab[i]->nbmineautour = 0;		
		char etat[] = " ";
	}	

	for (unsigned i = 0; i < g->nb_mines; i++) {
		int pos;
		cin >> pos;
		g->tab[pos]->mine == 1;
		g->tab[pos]->contenu = 'm';
		g->position_mines[i] = pos;		
	}
}

/*	
	@brief Affiche la position des mines
	@param[in] g: la grille
*/
void afficher_pos_mines(Grille* g) {	//affiche la position des mines
	for (unsigned int i = 0; i < g->nb_mines; i++) {
		cout << g->position_mines[i] << " ";
	}
}

//sprint 2

/*
    @brief Compte le nombre de mines adjacentes � la case
    @param[in] g: la grille
*/

void detection_mines(Grille* g) {

    unsigned int zero = 48; // chiffre 0 en ASCII qui comptera comme une cha�ne de caract�re

    for (unsigned int l = 0; l < g->nb_lignes * g->nb_colonne; ++l) {         //Initialisation des cases
        
            if (g->tab[l]->mine == 1) {
                g->tab[l]->mine = 1;
                if (l > g->nb_colonne 
                    && l < g->nb_colonne * g->nb_lignes - g->nb_colonne 
                    && l % g->nb_colonne != 0 
                    && l % g->nb_colonne != g->nb_colonne - 1) {   // les cases normales
                    
                    if (g->tab[l - 1]->mine != 1) // � gauche
                        g->tab[l - 1]->nbmineautour = zero;
                    if (g->tab[l + 1]->mine != 1) // � droite
                        g->tab[l + 1]->nbmineautour = zero;
                    if (g->tab[l - g->nb_colonne - 1]->mine != 1)  // en haut � gauche
                        g->tab[l - g->nb_colonne - 1]->nbmineautour = zero;
                    if (g->tab[l - g->nb_colonne + 1]->mine != 1)  // en haut � droite
                        g->tab[l - g->nb_colonne + 1]->nbmineautour = zero;
                    if (g->tab[l - g->nb_colonne]->mine != 1) // en haut
                        g->tab[l - g->nb_colonne]->nbmineautour = zero;
                    if (g->tab[l + g->nb_colonne - 1]->mine != 1) // en bas � gauche 
                        g->tab[l + g->nb_colonne - 1]->nbmineautour = zero;
                    if (g->tab[l + g->nb_colonne + 1]->mine != 1) // en bas � droite
                        g->tab[l + g->nb_colonne + 1]->nbmineautour = zero;
                    if (g->tab[l + g->nb_colonne]->mine != 1) // en bas
                        g->tab[l + g->nb_colonne]->nbmineautour = zero;
                }

                if (l == 0) { // coin haut � gauche
                    if (g->tab[l + 1]->mine != 1)  // � droite
                        g->tab[l + 1]->nbmineautour = zero;
                    if (g->tab[l + g->nb_colonne + 1]->mine != 1) // en bas � droite
                        g->tab[l + g->nb_colonne + 1]->nbmineautour = zero;
                    if (g->tab[l + g->nb_colonne]->mine != 1) // en bas
                        g->tab[l + g->nb_colonne]->nbmineautour = zero;
                }

                if (l < g->nb_colonne && l != 0 &&
                    l % g->nb_colonne != g->nb_colonne - 1) {    //ligne du haut

                    if (g->tab[l - 1]->mine != 1) // � gauche
                        g->tab[l - 1]->nbmineautour = zero;
                    if (g->tab[l + 1]->mine != 1)  // � droite
                        g->tab[l + 1]->nbmineautour = zero;
                    if (g->tab[l + g->nb_colonne - 1]->mine != 1) // en bas � gauche 
                        g->tab[l + g->nb_colonne - 1]->nbmineautour = zero;
                    if (g->tab[l + g->nb_colonne + 1]->mine != 1) // en bas � droite
                        g->tab[l + g->nb_colonne + 1]->nbmineautour = zero;
                    if (g->tab[l + g->nb_colonne]->mine != 1) // en bas
                        g->tab[l + g->nb_colonne]->nbmineautour = zero;                                        
                }

                if (l < g->nb_colonne && l % g->nb_colonne == g->nb_colonne - 1) {    //coin en haut a droite

                    if (g->tab[l - 1]->mine != 1)  // � gauche
                        g->tab[l - 1]->nbmineautour = zero;
                    if (g->tab[l + g->nb_colonne - 1]->mine != 1) // en bas � gauche 
                        g->tab[l + g->nb_colonne - 1]->nbmineautour = zero;
                    if (g->tab[l + g->nb_colonne]->mine != 1) // en bas
                        g->tab[l + g->nb_colonne]->nbmineautour = zero;                                        
                }

                if (l % g->nb_colonne == 0 
                    && l != 0 
                    && l < g->nb_colonne * g->nb_lignes - g->nb_colonne) {      //colonne de gauche

                    if (g->tab[l - g->nb_colonne]->mine != 1) // en haut
                        g->tab[l - g->nb_colonne]->nbmineautour = zero;
                    if (g->tab[l - g->nb_colonne + 1]->mine != 1)  // en haut � droite
                        g->tab[l - g->nb_colonne + 1]->nbmineautour = zero;
                    if (g->tab[l + 1]->mine != 1)  // � droite
                        g->tab[l + 1]->nbmineautour = zero;
                    if (g->tab[l + g->nb_colonne + 1]->mine != 1) // en bas � droite
                        g->tab[l + g->nb_colonne + 1]->nbmineautour = zero;
                    if (g->tab[l + g->nb_colonne]->mine != 1) // en bas
                        g->tab[l + g->nb_colonne]->nbmineautour = zero;
                }

                if (l >= g->nb_colonne * g->nb_lignes - g->nb_colonne 
                    && l % g->nb_colonne == 0) {     //coin en bas � gauche

                    if (g->tab[l - g->nb_colonne]->mine != 1) // en haut
                        g->tab[l - g->nb_colonne]->nbmineautour = zero;
                    if (g->tab[l - g->nb_colonne + 1]->mine != 1)  // en haut � droite
                        g->tab[l - g->nb_colonne + 1]->nbmineautour = zero;
                    if (g->tab[l + 1]->mine != 1)  // � droite
                        g->tab[l + 1]->nbmineautour = zero;                    
                }

                if (l >= g->nb_colonne * g->nb_lignes - g->nb_colonne 
                    && l % g->nb_colonne != 0 
                    && l % g->nb_colonne != g->nb_colonne - 1) {     //ligne du bas

                    if (g->tab[l - 1]->mine != 1)  // � gauche
                        g->tab[l - 1]->nbmineautour = zero;
                    if (g->tab[l + 1]->mine != 1)  // � droite
                        g->tab[l + 1]->nbmineautour = zero;
                    if (g->tab[l - g->nb_colonne - 1]->mine != 1)  // en haut � gauche
                        g->tab[l - g->nb_colonne - 1]->nbmineautour = zero;
                    if (g->tab[l - g->nb_colonne + 1]->mine != 1)  // en haut � droite
                        g->tab[l - g->nb_colonne + 1]->nbmineautour = zero;
                    if (g->tab[l - g->nb_colonne]->mine != 1) // en haut
                        g->tab[l - g->nb_colonne]->nbmineautour = zero;
                    
                }

                if (l >= g->nb_colonne * g->nb_lignes - g->nb_colonne 
                    && l % g->nb_colonne == g->nb_colonne - 1) {      //coin en bas � droite

                    if (g->tab[l - g->nb_colonne]->mine != 1) // en haut
                        g->tab[l - g->nb_colonne]->nbmineautour = zero;
                    if (g->tab[l - g->nb_colonne - 1]->mine != 1)  // en haut a gauche
                        g->tab[l - g->nb_colonne - 1]->nbmineautour = zero;
                    if (g->tab[l - 1]->mine != 1)  // a gauche
                        g->tab[l - 1]->nbmineautour =  zero;
                    
                }

                if (l % g->nb_colonne == g->nb_colonne - 1 
                    && l > g->nb_colonne 
                    && l < g->nb_colonne * g->nb_lignes - g->nb_colonne) {     //colonne de droite

                    if (g->tab[l - g->nb_colonne]->mine != 1) // en haut
                        g->tab[l - g->nb_colonne]->nbmineautour = zero;
                    if (g->tab[l - g->nb_colonne - 1]->mine != 1)  // en haut � gauche
                        g->tab[l - g->nb_colonne - 1]->nbmineautour = zero;
                    if (g->tab[l - 1]->mine != 1) // � gauche
                        g->tab[l - 1]->nbmineautour = zero;
                    if (g->tab[l + g->nb_colonne - 1]->mine != 1) // en bas � gauche 
                        g->tab[l + g->nb_colonne - 1]->nbmineautour = zero;
                    if (g->tab[l + g->nb_colonne]->mine != 1) // en bas
                        g->tab[l + g->nb_colonne]->nbmineautour = zero;
                    
                }
            }
        
    }

    for (unsigned int l = 0; l < g->nb_lignes * g->nb_colonne; ++l) {         //Incr�mentation des cases qui sont autour d'une mine. On ajoute +1 aux cases adjacentes des mines
        
        if (g->tab[l]->mine == 1) {
            g->tab[l]->mine = 1;
            if (l > g->nb_colonne
                && l < g->nb_colonne * g->nb_lignes - g->nb_colonne
                && l % g->nb_colonne != 0
                && l % g->nb_colonne != g->nb_colonne - 1) {   // les cases normales

                if (g->tab[l - 1]->mine != 1) // � gauche
                    g->tab[l - 1]->nbmineautour += 1;
                if (g->tab[l + 1]->mine != 1) // � droite
                    g->tab[l + 1]->nbmineautour += 1;
                if (g->tab[l - g->nb_colonne - 1]->mine != 1)  // en haut � gauche
                    g->tab[l - g->nb_colonne - 1]->nbmineautour += 1;
                if (g->tab[l - g->nb_colonne + 1]->mine != 1)  // en haut � droite
                    g->tab[l - g->nb_colonne + 1]->nbmineautour += 1;
                if (g->tab[l - g->nb_colonne]->mine != 1) // en haut
                    g->tab[l - g->nb_colonne]->nbmineautour += 1;
                if (g->tab[l + g->nb_colonne - 1]->mine != 1) // en bas � gauche 
                    g->tab[l + g->nb_colonne - 1]->nbmineautour += 1;
                if (g->tab[l + g->nb_colonne + 1]->mine != 1) // en bas � droite
                    g->tab[l + g->nb_colonne + 1]->nbmineautour += 1;
                if (g->tab[l + g->nb_colonne]->mine != 1) // en bas
                    g->tab[l + g->nb_colonne]->nbmineautour += 1;
            }

            if (l == 0) { // coin haut � gauche
                if (g->tab[l + 1]->mine != 1)  // � droite
                    g->tab[l + 1]->nbmineautour += 1;
                if (g->tab[l + g->nb_colonne + 1]->mine != 1) // en bas � droite
                    g->tab[l + g->nb_colonne + 1]->nbmineautour += 1;
                if (g->tab[l + g->nb_colonne]->mine != 1) // en bas
                    g->tab[l + g->nb_colonne]->nbmineautour += 1;
            }

            if (l < g->nb_colonne && l != 0 &&
                l % g->nb_colonne != g->nb_colonne - 1) {    //ligne du haut

                if (g->tab[l - 1]->mine != 1) // � gauche
                    g->tab[l - 1]->nbmineautour += 1;
                if (g->tab[l + 1]->mine != 1)  // � droite
                    g->tab[l + 1]->nbmineautour += 1;
                if (g->tab[l + g->nb_colonne - 1]->mine != 1) // en bas � gauche 
                    g->tab[l + g->nb_colonne - 1]->nbmineautour += 1;
                if (g->tab[l + g->nb_colonne + 1]->mine != 1) // en bas � droite
                    g->tab[l + g->nb_colonne + 1]->nbmineautour += 1;
                if (g->tab[l + g->nb_colonne]->mine != 1) // en bas
                    g->tab[l + g->nb_colonne]->nbmineautour += 1;

            }

            if (l < g->nb_colonne && l % g->nb_colonne == g->nb_colonne - 1) {    //coin en haut a droite

                if (g->tab[l - 1]->mine != 1)  // � gauche
                    g->tab[l - 1]->nbmineautour += 1;
                if (g->tab[l + g->nb_colonne - 1]->mine != 1) // en bas � gauche 
                    g->tab[l + g->nb_colonne - 1]->nbmineautour += 1;
                if (g->tab[l + g->nb_colonne]->mine != 1) // en bas
                    g->tab[l + g->nb_colonne]->nbmineautour += 1;

            }

            if (l % g->nb_colonne == 0
                && l != 0
                && l < g->nb_colonne * g->nb_lignes - g->nb_colonne) {      //colonne de gauche

                if (g->tab[l - g->nb_colonne]->mine != 1) // en haut
                    g->tab[l - g->nb_colonne]->nbmineautour += 1;
                if (g->tab[l - g->nb_colonne + 1]->mine != 1)  // en haut � droite
                    g->tab[l - g->nb_colonne + 1]->nbmineautour += 1;
                if (g->tab[l + 1]->mine != 1)  // � droite
                    g->tab[l + 1]->nbmineautour += 1;
                if (g->tab[l + g->nb_colonne + 1]->mine != 1) // en bas � droite
                    g->tab[l + g->nb_colonne + 1]->nbmineautour += 1;
                if (g->tab[l + g->nb_colonne]->mine != 1) // en bas
                    g->tab[l + g->nb_colonne]->nbmineautour += 1;

            }

            if (l >= g->nb_colonne * g->nb_lignes - g->nb_colonne
                && l % g->nb_colonne == 0) {     //coin en bas � gauche

                if (g->tab[l - g->nb_colonne]->mine != 1) // en haut
                    g->tab[l - g->nb_colonne]->nbmineautour += 1;
                if (g->tab[l - g->nb_colonne + 1]->mine != 1)  // en haut � droite
                    g->tab[l - g->nb_colonne + 1]->nbmineautour += 1;
                if (g->tab[l + 1]->mine != 1)  // � droite
                    g->tab[l + 1]->nbmineautour += 1;

            }

            if (l >= g->nb_colonne * g->nb_lignes - g->nb_colonne
                && l % g->nb_colonne != 0
                && l % g->nb_colonne != g->nb_colonne - 1) {     //ligne du bas

                if (g->tab[l - 1]->mine != 1)  // � gauche
                    g->tab[l - 1]->nbmineautour += 1;
                if (g->tab[l + 1]->mine != 1)  // � droite
                    g->tab[l + 1]->nbmineautour += 1;
                if (g->tab[l - g->nb_colonne - 1]->mine != 1)  // en haut � gauche
                    g->tab[l - g->nb_colonne - 1]->nbmineautour += 1;
                if (g->tab[l - g->nb_colonne + 1]->mine != 1)  // en haut � droite
                    g->tab[l - g->nb_colonne + 1]->nbmineautour += 1;
                if (g->tab[l - g->nb_colonne]->mine != 1) // en haut
                    g->tab[l - g->nb_colonne]->nbmineautour += 1;

            }

            if (l >= g->nb_colonne * g->nb_lignes - g->nb_colonne
                && l % g->nb_colonne == g->nb_colonne - 1) {      //coin en bas � droite

                if (g->tab[l - g->nb_colonne]->mine != 1) // en haut
                    g->tab[l - g->nb_colonne]->nbmineautour += 1;
                if (g->tab[l - g->nb_colonne - 1]->mine != 1)  // en haut a gauche
                    g->tab[l - g->nb_colonne - 1]->nbmineautour += 1;
                if (g->tab[l - 1]->mine != 1)  // a gauche
                    g->tab[l - 1]->nbmineautour += 1;

            }

            if (l % g->nb_colonne == g->nb_colonne - 1
                && l > g->nb_colonne
                && l < g->nb_colonne * g->nb_lignes - g->nb_colonne) {     //colonne de droite

                if (g->tab[l - g->nb_colonne]->mine != 1) // en haut
                    g->tab[l - g->nb_colonne]->nbmineautour += 1;
                if (g->tab[l - g->nb_colonne - 1]->mine != 1)  // en haut � gauche
                    g->tab[l - g->nb_colonne - 1]->nbmineautour += 1;
                if (g->tab[l - 1]->mine != 1) // � gauche
                    g->tab[l - 1]->nbmineautour += 1;
                if (g->tab[l + g->nb_colonne - 1]->mine != 1) // en bas � gauche 
                    g->tab[l + g->nb_colonne - 1]->nbmineautour += 1;
                if (g->tab[l + g->nb_colonne]->mine != 1) // en bas
                    g->tab[l + g->nb_colonne]->nbmineautour += 1;

            }
			if (g->tab[l]->nbmineautour == 0)
				g->tab[l]->contenu = ' ';
			std::string str = std::to_string(g->tab[l]->nbmineautour);
			g->tab[l]->contenu = str;
        }        
    }    
}

/*	
	@brief Permet de jouer les coups entr� par l'utilisateur
	@param[in] g: la grille
*/
void jouer(Grille* g) {
	//historique
	unsigned int nb_coups;
	cin >> nb_coups;
	

	char* action = new char[nb_coups];
	int* pos_action = new int[nb_coups];

	for (unsigned int i = 0; i < nb_coups; i++) {
		cin >> action[i] >> pos_action[i];
		g->tab[pos_action[i]]->etat = action[i]; // affecte l'action dans etat en fonction de la pos_action
		
	}
	
	cout << endl;
}

/*
    @brief Affiche une grille en fonction du nombre de colonne et de ligne
    @param[in] g: la grille
*/

void afficher_grille(Grille* g) {
	
	cout << g->nb_lignes << " " << g->nb_colonne << endl;

	//Affichage de la grille 

	unsigned int position = 0;
	for (unsigned int i = 0; i < g->nb_lignes; i++) {
		for (unsigned int j = 1; j <= g->nb_colonne; j++) {
			cout << " ---";
		}
		cout << endl;			
																		
		for (unsigned int k = 0; k < g->nb_colonne; k++) {
			if (g->tab[position]->etat == 'D') { 
				cout << "| " << g->tab[position]->contenu << " "; 
			}
			else {
				if (g->tab[position]->etat == 'M') {
					cout << "| " << "x" << " ";
				}
				else { 
					cout << "| " << "." << " ";
				}
			}
			position = position + 1;
		}
		cout << "|" << endl;
	}
	for (unsigned int m = 0; m < g->nb_colonne; m++) {
		cout << " ---";
	}
	cout << endl;
}


