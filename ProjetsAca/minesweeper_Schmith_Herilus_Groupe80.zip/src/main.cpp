//minesweeper
/*Biblioth�ques utilis�es*/
#include <stdio.h>
#include <cassert>
#include <cstdlib>
#include <random>
#include <iostream>
#include <sstream>
#include <string>
using namespace std;


int main() {
	Grille g;
	Case c;

	int operation;
	cin >> operation;
	switch (operation) {
	case 1:
		creer_probleme_random(&g);
		cout << g.nb_lignes << " " << g.nb_colonne << " " << g.nb_mines << " ";
		afficher_pos_mines(&g);
		cout << endl;
		break;
	case 2:
		creer_probleme_util(&g);
		cases_adjacentes(&g);
		jouer(&g, &c);

		/*for (unsigned int i = 0; i < g.nb_colonne * g.nb_lignes; i++) {
			detection_mines(&g, i);
		}*/
		afficher_grille(&g);
		break;
	default:
		break;
		// code block
	}
}