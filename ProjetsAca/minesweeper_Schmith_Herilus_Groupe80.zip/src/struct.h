#pragma once

/* @brief Le type Case
   ayant pout attribut
   le non sign� mine,
   le char etat,
   le non sign� nbmineautour,
   le string contenu
*/

typedef struct Case {		//Structure Case

	unsigned int mine;			// reprvariable de type int
	char etat;					//etat de la case de type char
	unsigned int nbmineautour;	// le nombre de mine autour de la case de type unsigned int	
	std::string contenu;		// contient ce qui va etre affich� de type string


};


/*	@brief Le type Grille
	ayant pour attribut
	le non sign� nb_colonne
	le non sign� nb_lignes,
	le non sign� nb_mines
	le tableau d'entier position_mines,
	la case de type Case tab
*/

typedef struct Grille {
	unsigned int nb_colonne;
	unsigned int nb_lignes;
	unsigned int nb_mines;
	int* position_mines;
	Case** tab;

};


/