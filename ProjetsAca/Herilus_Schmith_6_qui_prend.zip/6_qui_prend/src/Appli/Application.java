package Appli;
import MonPaquetage.Carte;
import MonPaquetage.Console;
import MonPaquetage.Jeu;
import MonPaquetage.Joueur;
import MonPaquetage.Paquet;
import MonPaquetage.Serie;

public class Application {	

	public static void main(String[] args) {
		
		Jeu game = new Jeu();

		game.lecture("D:\\6_qui_prend\\6_qui_prend\\src\\Appli\\config.txt");
		assert(game.Entre2Et10());

		
		System.out.print("Les " + game.getNbJoueurs() + " joueurs sont " + game.toStringNomJoueurs()); 	
		System.out.println(" Merci de jouer � 6 qui prend !");		
		
		Paquet p = new Paquet();
		for (int i = 1; i <= game.getNbCartes() ; i++) {	//Cr�ation du paquet et ses cartes
			Carte c = new Carte(i);
			p.add(c);
		}

		p.melanger();
		
		for (int j = 0; j < game.getNbSeries(); j++) {	//Cr�ation des s�ries
			Serie serie = new Serie();
			game.addSerie(serie);
			serie.ajouter(p.TirerCarte());				
		}
		game.TrierSerie();		
		
		for (int k = 0; k < game.getNbJoueurs(); k++) {	//Piochage des cartes pour tous les joueurs
			game.getListeJoueurs().get(k);
			for ( int l = 0; l < Joueur.getnbcartesjoueursmax(); l++) {
				game.getListeJoueurs().get(k).piocher(p);
				
			}
			game.getListeJoueurs().get(k).attribuer(); // d�finit le propri�taire des cartes			
		}
		
		for (int i = 0 ; i < game.getNbJoueurs(); i++) {
			System.out.println("A " + game.getListeJoueurs().get(i).toStringNom() + " de jouer");
			
			Console.pause();	//pause		
			for (int j = 0; j < game.getNbSeries(); j++) {
				game.getListeSerie().get(j).TrierSerie();
				System.out.print("- S�rie n� " + (j+1) + " : "); 
				System.out.println(game.getListeSerie().get(j).AfficherSerie());	//Affiche la s�rie 
								 
			}
			
			game.getListeJoueurs().get(i).Trier(); // Permet de trier les cartes du joueur
			System.out.println("- Vos cartes : " + game.getListeJoueurs().get(i).afficher_carte_joueur());		// Affiche les cartes du joueur
			System.out.print("Saisissez votre choix : ");
			game.getListeJoueurs().get(i).poserTest();	//Permet de poser la carte choisi
			game.addChoix(game.getListeJoueurs().get(i).getChoixjoueurcarte());
			Console.clearScreen();	//clearScreen
				
		}
		
		game.TrierChoix();		
		System.out.println("Les cartes " + game.AfficherChoix() + " ont �t� pos�es.");		
		game.jouer();		
		System.out.println(game.getListeSerie().get(0).AfficherSerie()); 		

	}

}
