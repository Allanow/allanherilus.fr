package MonPaquetage;

import static org.junit.Assert.*;

import org.junit.Test;

public class JeuTest {

	@Test
	public void testJeu() {
		Jeu a = new Jeu();
		assertTrue(a.getNbCartes() == 104); 		
	}

	@Test
	public void testEntre2Et10() {
		Jeu a = new Jeu();
		Jeu b = new Jeu();
		Jeu c = new Jeu();
		
		a.setNbJoueurs(5);
		b.setNbJoueurs(1);
		c.setNbJoueurs(13);
		assertTrue(a.Entre2Et10());
		assertFalse(b.Entre2Et10());
		assertFalse(c.Entre2Et10());
	}

	@Test
	public void testLecture() {
		Jeu a = new Jeu();
		a.lecture("D:\\6_qui_prend\\6_qui_prend\\src\\Appli\\config.txt");
		assertTrue(a.getListeJoueurs().get(0).toStringNom().equals("John"));
	}

	@Test
	public void testGetNbCartes() {
		Jeu a = new Jeu();
		assertTrue(a.getNbCartes() == 104);
		assertFalse(a.getNbCartes() == 56);
	}

	@Test
	public void testGetNbSeries() {
		Jeu a = new Jeu();
		assertTrue(a.getNbSeries() == 4);
		assertFalse(a.getNbCartes() == 56);
	}

	@Test
	public void testGetNbJoueurs() {
		Jeu a = new Jeu();
		a.lecture("D:\\6_qui_prend\\6_qui_prend\\src\\Appli\\config.txt");
		assertTrue(a.getNbJoueurs() == 4);
		assertFalse(a.getNbJoueurs() == 12);
	}

	@Test
	public void testAddJoueurs() {
		Jeu a = new Jeu();
		Joueur j1 = new Joueur();
		j1.setNom("Allan");
		a.addJoueurs(j1);
		assertTrue(a.getListeJoueurs().get(0).toStringNom() == "Allan");
		assertFalse(a.getListeJoueurs().get(0).toStringNom() == "Ulrich");
	}

	@Test
	public void testSetNbJoueurs() {
		Jeu a = new Jeu();
		Jeu b = new Jeu();
		Jeu c = new Jeu();
		
		a.setNbJoueurs(5);
		b.setNbJoueurs(1);
		c.setNbJoueurs(13);
		assertTrue(a.getNbJoueurs() == 5);
		assertTrue(b.getNbJoueurs() == 1);
		assertTrue(c.getNbJoueurs() == 13);
		
	}

	@Test
	public void testGetListeJoueurs() {
		Jeu a = new Jeu();
		Joueur j1 = new Joueur();
		Joueur j2 = new Joueur();
		j1.setNom("Allan");
		j2.setNom("Ulrich");
		a.addJoueurs(j1);
		a.addJoueurs(j2);
		assertTrue(a.getListeJoueurs().get(0).toStringNom() == "Allan");
		assertFalse(a.getListeJoueurs().get(0).toStringNom() == "Ulrich");
				
	}
	
	@Test
	public void testToStringNomJoueurs() {
		Jeu a = new Jeu();
		Joueur j1 = new Joueur();
		j1.setNom("Allan");
		a.addJoueurs(j1);
		assertTrue(a.getListeJoueurs().get(0).toStringNom() == "Allan");
		assertFalse(a.getListeJoueurs().get(0).toStringNom() == "Ulrich");	
	}

	@Test
	public void testAddSerie() {
		Jeu a = new Jeu();
		Serie s1 = new Serie();
		a.addSerie(s1);
		assertTrue(a.getListeSerie().get(0) == s1);	
	}

	@Test
	public void testGetListeSerie() {
		Jeu a = new Jeu();
		Serie s1 = new Serie();
		a.addSerie(s1);
		assertTrue(a.getListeSerie().get(0) == s1);
	}

	@Test
	public void testAddChoix() {
		Jeu a = new Jeu();
		Joueur j1 = new Joueur();
		j1.setNom("Allan");		
		a.addJoueurs(j1);
		Carte c = new Carte(15);
		j1.carte_joueur.add(c);
		assertTrue(a.AfficherChoix().equals("15 (Allan), "));
	}

	@Test
	public void testTrierChoix() {
		Jeu a = new Jeu();
		Jeu b = new Jeu();
		for (int i = 1; i < 20; i++) {
			Carte c = new Carte(i);
			Carte d = new Carte(i);
			a.addChoix(c);
			b.addChoix(d);
		}
		a.TrierChoix();
		assertFalse(a.AfficherChoix() == b.AfficherChoix());
		
	}

	@Test
	public void testTrierSerie() {
		Jeu a = new Jeu();
		Serie s1 = new Serie();
		Serie s2 = new Serie();
		a.addSerie(s1);
		a.addSerie(s2);
		
		
		for (int i = 1; i < 6; i++) {
			Carte c = new Carte(i);
			a.getListeSerie().get(0).ajouter(c);
						
		}
		for (int i = 8; i < 15; i++) {
			Carte c = new Carte(i);	
			a.getListeSerie().get(1).ajouter(c);					
		}
		a.TrierSerie();
		assertTrue(a.getListeSerie().get(0).equals(s1));
		
	}

	@Test
	public void testAfficherChoix() {
		fail("Not yet implemented");
	}

	@Test
	public void testJouer() {
		fail("Not yet implemented");
	}

	@Test
	public void testRemplacerSerie() {
		fail("Not yet implemented");
	}

}
