package MonPaquetage;

import static org.junit.Assert.*;

import org.junit.Test;

public class JoueurTest {

	@Test
	public void testJoueur() {
		Joueur j1 = new Joueur();
		assertTrue(j1.getnbcartesjoueursmax() == 10);
	}

	@Test
	public void testSetNom() {
		Joueur j1 = new Joueur();
		j1.setNom("Allan");
		assertTrue(j1.toStringNom().equals("Allan"));
		assertFalse(j1.toStringNom().equals("Ulrich"));
	}

	@Test
	public void testToStringNom() {
		Joueur j1 = new Joueur();
		j1.setNom("Allan");
		assertTrue(j1.toStringNom().equals("Allan"));
		assertFalse(j1.toStringNom().equals("Ulrich"));
	}

	@Test
	public void testTrier() {
		Joueur j = new Joueur();
		
		for (int i = 1; i < 10; i++) {
			Carte c = new Carte(i);
			j.carte_joueur.add(c);
		}
		j.Trier();
		assertTrue(j.carte_joueur.get(0).getCarteva() == 1);
		assertTrue(j.carte_joueur.get(8).getCarteva() == 9);
	}

	@Test
	public void testAfficher_carte_joueur() {
		Joueur j = new Joueur();
		
		for (int i = 1; i < 3; i++) {
			Carte c = new Carte(i);
			j.carte_joueur.add(c);
		}
		assertTrue(j.afficher_carte_joueur().equals("1, 2"));
	}

	@Test
	public void testGetnbcartesjoueursmax() {
		Joueur j = new Joueur();
		assertTrue(j.getnbcartesjoueursmax() == 10);
		assertFalse(j.getnbcartesjoueursmax() == 23);
	}

	@Test
	public void testPiocher() {
		Joueur j = new Joueur();
		Paquet p = new Paquet();
		for (int i = 1; i <= 10 ; i++) {
			Carte c = new Carte(i);
			p.add(c);
		}
		j.piocher(p);
		assertTrue(j.carte_joueur.get(0).getCarteva() == 1);
	}

	@Test
	public void testAttribuer() {
		Joueur j = new Joueur();		
		j.setNom("Allan");
		Paquet p = new Paquet();
		for (int i = 1; i <= 10 ; i++) {
			Carte c = new Carte(i);
			p.add(c);
			j.piocher(p);			
		}
		j.attribuer();
		assertTrue(j.carte_joueur.get(0).getPropri�taire().equals("Allan"));
		
	}

	@Test
	public void testGetCarte() {
		Joueur j = new Joueur();		
		j.setNom("Allan");
		Paquet p = new Paquet();
		for (int i = 1; i <= 10 ; i++) {
			Carte c = new Carte(i);
			p.add(c);
			j.piocher(p);			
		}
		j.Trier();
		assertTrue(j.getCarte(1).getCarteva()== j.carte_joueur.get(0).getCarteva());
	}

	@Test
	public void testPoserTest() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetChoixjoueurcarte() {
		fail("Not yet implemented");
	}

	@Test
	public void testEstdansMain() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetTeteboeuf() {
		fail("Not yet implemented");
	}

}
