package MonPaquetage;
import java.util.ArrayList;
import java.util.Collections;

public class Paquet {
	
	private ArrayList<Carte> paquet;	
	
	public Paquet() {
		paquet = new ArrayList<Carte>();
	}
	
	public void add(Carte c) {	//Permet d'ajouter une carte dans le paquet	
		this.paquet.add(c); 		
	}		
	
	public void melanger() {	//Permet de m�langer les cartes du paquet	
		Collections.shuffle(this.paquet);
	}	
	
	public Carte TirerCarte() {	//Permet de tirer la premi�re carte du paquet	
		Carte r = this.paquet.get(0);
		this.paquet.remove(0); 
		return r;		
	}
	
	public int getsize() { 		//Permet d'obtenir la taille du paquet
		return this.paquet.size();
	}
	
}

