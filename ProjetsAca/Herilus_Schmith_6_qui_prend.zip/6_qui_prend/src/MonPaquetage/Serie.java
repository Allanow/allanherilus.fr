package MonPaquetage;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Serie {
	
	private ArrayList<Carte> serie;
	private int numero;
	private static int serie_cpt = 0;
	private int nb_carte = 0;
	private static final int MAXCARTES = 5;	
	
	public Serie() {
		serie = new ArrayList<Carte>();
		this.numero = ++serie_cpt;
	}
	
	public Carte getlastCarte() {		//Permet d'obtenir la derni�re carte d'une s�rie	
		return serie.get(nb_carte - 1);
	}
	
	public ArrayList<Carte> getserie() {	//Permet d'obtenir la s�rie de Serie	
		return this.serie;
	}
	
	public boolean EstPosable(Carte c) {	//V�rifie si la carte est sup�rieure � la derni�re carte de la s�rie	
		if (nb_carte >= MAXCARTES) {
			return false;
		}
		else if(nb_carte == 0) {
			return true;
		}
		
		else if (c.getCarteva() < serie.get(serie.size()-1).getCarteva()) {
			return false;
		}		
		else
			return true;		
	}
	
	public static int getMaxCartes() {	//Permet d'obtenir le nombre de carte maximal d'une s�rie	
		return MAXCARTES;
	}
	
	public void DecrementeNbcarte() {	//Permet de d�cr�menter le nombre de carte d'une s�rie	
		nb_carte--;
	}	
	
	public void ajouter(Carte c) {	//Permet d'ajouter une carte dans la s�rie	
		if (EstPosable(c) == true)
			this.serie.add(c);
			nb_carte++;
	}
	
	public void TrierSerie() {	//Permet de trier les cartes de la s�rie par ordre croissant	
		  Collections.sort(serie, Carte.ComparatorValeur);
	}	
		
	public String AfficherSerie() {	//Permet d'afficher les cartes d'une s�rie	
		String s = "";
		for (int i = 0; i < nb_carte; i++) {
			s += serie.get(i).getCarteva();
			if (serie.get(i).gettete_boeuf()> 1) {
				 s += " (" + serie.get(i).gettete_boeuf() + ")"; 
			}
			if (i < nb_carte - 1)
				s += ", ";
		}
		return s;
	}	
	
	public static Comparator<Serie> ComparatorValeur = new Comparator<Serie>() {
	     
        @Override
        public int compare(Serie s1, Serie s2) {
            return (int) (s1.getserie().get(s1.nb_carte - 1).getCarteva() - s2.getserie().get(s1.nb_carte - 1).getCarteva());
        }
    };
	
	
}
