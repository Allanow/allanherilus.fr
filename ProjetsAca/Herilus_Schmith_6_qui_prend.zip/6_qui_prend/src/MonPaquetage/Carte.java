package MonPaquetage;
import java.util.Comparator;

public class Carte {
	
	private int valeur;
	private int tete_boeuf;
	private String proppri�taire;	
	
	public Carte(int valeur) {		
		this.valeur = valeur;
		this.tete_boeuf = affectboeuf(valeur);		
		this.proppri�taire = null;
	}		
	
	public  int affectboeuf(int numero) {	//Permet d'affecter le nombre de tete de boeufs.	
				
		if (taille(numero) > 1 && String.valueOf(numero).substring(taille(numero) - 1).equals(String.valueOf(5)) && String.valueOf(numero).substring(taille(numero) - 2,1).equals(String.valueOf(5)))
			return 7;
		
		if (String.valueOf(numero).substring(taille(numero) - 1).equals(String.valueOf(5)))
			return 2;
		
		if (String.valueOf(numero).substring(taille(numero) - 1).equals(String.valueOf(0)))
			return 3;
		
		if (taille(numero) > 1 && String.valueOf(numero).substring(taille(numero) - 1).equals(String.valueOf(numero).substring(taille(numero) - 2,1)))
			return 5;
		else
			return 1;							
	}
	
	public int taille( int numero) {
		return Integer.toString(numero).length();
	}
	
	public Carte () {		
		
	}	
	
	public int getCarteva() {	//Permet d'obtenir la valeur d'une carte		
		return valeur;		
	}
	
	public Carte getCartee() {	//Permet de retourner une carte		
		return this;
	}
	
	public String getPropri�taire() {	//Permet d'obtenir le propri�taire d'une carte	
		return this.proppri�taire;
	}
	
	public void setPropri�taire(String prop) {	//Permet de modifier le propri�raire d'une carte	
		this.proppri�taire = prop;
	}	
	
	public int gettete_boeuf () {	//Permet d'obtenir le nombre de t�te de boeuf d'une carte	
		return tete_boeuf;
	}
	
	/*
     * Comparator pour le tri des cartes par valeur 
     */
    public static Comparator<Carte> ComparatorValeur = new Comparator<Carte>() {
     
        @Override
        public int compare(Carte e1, Carte e2) {
            return (int) (e1.getCarteva() - e2.getCarteva());
        }
    };
	

}
