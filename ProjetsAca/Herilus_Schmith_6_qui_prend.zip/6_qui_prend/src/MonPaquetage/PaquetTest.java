package MonPaquetage;

import static org.junit.Assert.*;

import org.junit.Test;

public class PaquetTest {

	@Test
	public void testPaquet() {
		Paquet a = new Paquet();
		Paquet b = new Paquet();
		
		for (int i = 1; i <= 20 ; i++) {	
			Carte c = new Carte(i);
			a.add(c);
			b.add(c);
		}		
		assertTrue(a.TirerCarte() == b.TirerCarte());
	}

	@Test
	public void testAdd() {
		Paquet a = new Paquet();
		Carte c = new Carte(55);
		a.add(c);		
		assertTrue(a.TirerCarte() == c );
	}

	@Test
	public void testMelanger() {
		Paquet a = new Paquet();
		Paquet b = new Paquet();
		
		for (int i = 1; i <= 104 ; i++) {	
			Carte c = new Carte(i);
			a.add(c);
			b.add(c);
		}
		a.melanger();
		b.melanger();
		assertFalse(a.TirerCarte() == b.TirerCarte());
	}

	@Test
	public void testTirerCarte() {
		Paquet a = new Paquet();
		Carte c = new Carte(55);
		a.add(c);		
		assertTrue(a.TirerCarte() == c );
	}

	@Test
	public void testGetsize() {
		Paquet a = new Paquet();
		Paquet b = new Paquet();
		
		for (int i = 1; i < 20 ; i++) {	
			Carte c = new Carte(i);
			a.add(c);
			b.add(c);
		}	
		assertTrue(a.getsize() == 19);
		assertTrue(a.getsize() == b.getsize());
		assertTrue(a.TirerCarte() == b.TirerCarte());		
	}

}
