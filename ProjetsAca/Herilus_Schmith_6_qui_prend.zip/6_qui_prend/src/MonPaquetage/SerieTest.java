package MonPaquetage;

import static org.junit.Assert.*;

import org.junit.Test;

public class SerieTest {

	@Test
	public void testSerie() {
		Serie s = new Serie();
		
	}

	@Test
	public void testGetlastCarte() {
		Serie s = new Serie();
		for (int i = 1; i < 6; i++) {
			Carte c = new Carte(i);
			s.ajouter(c);
		}
		assertTrue(s.getlastCarte().equals(s.getserie().get( 6-2)));
	}

	@Test
	public void testGetserie() {
		Serie s = new Serie();
		for (int i = 1; i < 6; i++) {
			Carte c = new Carte(i);
			s.ajouter(c);
		}
		assertTrue(s.getserie().get(4).equals(s.getlastCarte()));
	}

	@Test
	public void testEstPosable() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetMaxCartes() {
		Serie s = new Serie();
		assertTrue(s.getMaxCartes() == 5);
	}

	@Test
	public void testDecrementeNbcarte() {
		fail("Not yet implemented");
	}

	@Test
	public void testAjouter() {
		Serie s = new Serie();
		Carte c = new Carte(5);
		s.ajouter(c);
		assertTrue(s.getserie().get(0).equals(c));
	}

	@Test
	public void testTrierSerie() {
		fail("Not yet implemented");
	}

	@Test
	public void testAfficherSerie() {
		fail("Not yet implemented");
	}

}
