package MonPaquetage;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Collections;

public class Joueur {
	private int numero;
	private static int numcpt = 0;
	private String nom;
	private int tete_boeuf_joueur;
	ArrayList<Carte> carte_joueur;
	private Carte choixjoueurcarte;
	private static int nb_cartes_joueur_max = 10;
	private int nb_carte_act;
	
	
	Joueur() {
		tete_boeuf_joueur = 0;
		this.numero = numcpt++;
		choixjoueurcarte = new Carte();
		carte_joueur = new ArrayList<Carte>();
		nb_carte_act = 0;
	}
	
	public void setNom(String nombis) {	//Permet de modifier le nom du joueur	
		nom = nombis;
	}
	
	public String toStringNom () { //Permet de retourner le nom du joueur	
		String s = nom;
		return s;
	}
	
	public void Trier() {	//Permet de trier les cartes du joueur par ordre croissant	
		  Collections.sort(carte_joueur, Carte.ComparatorValeur);
	}		 	
	
	public String afficher_carte_joueur () {	//Permet d'afficher les cartes du joueur	
		String s = "";
		for (int i = 0; i < nb_carte_act; i++) {
			s += carte_joueur.get(i).getCarteva();
			if (carte_joueur.get(i).gettete_boeuf()> 1) {
				 s += " (" + carte_joueur.get(i).gettete_boeuf() + ")"; 
			}
			if (i < nb_carte_act - 1)
				s += ", ";
		}
		return s;
	}
	
	public static int getnbcartesjoueursmax() {	//Permet d'obtenir le nombre de carte max par joueur	
		return nb_cartes_joueur_max;
	}

	public void piocher(Paquet p) { //Permet de piocher une carte du paquet	
		carte_joueur.add(p.TirerCarte());		
		nb_carte_act++;		
	}
	
	public void attribuer() {	//Permet d'attribuer le propri�taire � chaque carte d'un joueur	
		for (int i = 0; i < nb_carte_act ; i++) {
			carte_joueur.get(i).setPropri�taire(nom);
		}
	}
	
	public Carte getCarte(int valeur) {	//Permet d'obtenir une carte pr�sente dans carte_joueur en fonction de sa valeur	
		assert(EstdansMain(valeur)== false);
		for (int i = 0; i < nb_carte_act; i++) {
			if (valeur == carte_joueur.get(i).getCarteva())
				return carte_joueur.get(i).getCartee();
		}
		return null;
	}
	
	public void poserTest() {	//Permet de poser une carte		
		Scanner sc = new Scanner (System.in);		
		boolean pos� = false; 
		
		while (pos� == false) {
			int choix = sc.nextInt();
			if (EstdansMain(choix) == false) {
				System.out.print("Vous n�avez pas cette carte, saisissez votre choix : ");
			}
			
			if (EstdansMain(choix) == true) {
				choixjoueurcarte = getCarte(choix);
				
				for (int i = 0; i < nb_carte_act; i++) {	//retirer de la main
					if (choix == carte_joueur.get(i).getCarteva()) {
						carte_joueur.remove(i);
						nb_carte_act --;
						pos� = true;
					}
				}				
			}			
		}				
	}
	
	public Carte getChoixjoueurcarte() {	//Permet d'obtenir choixjoueurcarte		
		return choixjoueurcarte;
	}
	
	public boolean EstdansMain(int val) {	//Permet de v�rifier si une carte est pr�sente dans carte_joueur	
		for (int i = 0; i < nb_carte_act; i++) {
			if (val == carte_joueur.get(i).getCarteva()) {
				return true;
			}
		}
		return false;		
	}
	
	public void setTeteboeuf(int tete_boeuf) {	//Permet de modifier le nombre de t�te de boeuf d'un joueur		
		this.tete_boeuf_joueur = tete_boeuf;
	}

}
