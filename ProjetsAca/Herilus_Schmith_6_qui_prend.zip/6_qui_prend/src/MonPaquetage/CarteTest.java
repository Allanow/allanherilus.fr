package MonPaquetage;

import static org.junit.Assert.*;

import org.junit.Test;

public class CarteTest {

	@Test
	public void testCarteInt() {
		Carte a = new Carte(1), b = new Carte(2);
		assertFalse(a.toString().equals(b.toString()));		
	}

	@Test
	public void testAffectboeufInt() {
		Carte a = new Carte(71); 
		Carte b = new Carte(55); 
		Carte c = new Carte(88); 
		Carte d = new Carte(45);

		
		assertTrue(a.gettete_boeuf() == 1);
		System.out.println(a.gettete_boeuf());
	
		assertTrue(b.gettete_boeuf() == 7);
		System.out.println(b.gettete_boeuf());
		
		assertTrue(c.gettete_boeuf() == 5);		
		System.out.println(c.gettete_boeuf());
		
		System.out.println(d.gettete_boeuf());
		assertTrue(d.gettete_boeuf() == 2);
		
	}

	@Test
	public void testCarte() {
			
	}

	@Test
	public void testGetCarteva() {
		Carte a = new Carte(71), b = new Carte(55);
		
		assertTrue(a.getCarteva() == 71);
		assertTrue(b.getCarteva() == 55);
		
	}

	@Test
	public void testGetCartee() {
		Carte a = new Carte(71);
		Carte b = new Carte(55);
		
		assertTrue(a == a.getCartee());
		assertTrue(b == b.getCartee());
		assertFalse(a.getCartee() == b.getCartee());
	}

	@Test
	public void testGetPropri�taire() {
		Carte a = new Carte(71);
		Carte b = new Carte(55);
		
		a.setPropri�taire("Allan");
		b.setPropri�taire("Ulrich");
		
		assertTrue(a.getPropri�taire().equals("Allan"));
		assertTrue(b.getPropri�taire().equals("Ulrich"));
		assertFalse(a.getPropri�taire().equals(b.getPropri�taire()));
		
	}

	@Test
	public void testSetPropri�taire() {
		Carte a = new Carte(71);
		Carte b = new Carte(55);
		
		a.setPropri�taire("Allan");
		b.setPropri�taire("Ulrich");
		
		assertTrue(a.getPropri�taire().equals("Allan"));
		assertTrue(b.getPropri�taire().equals("Ulrich"));
		assertFalse(a.getPropri�taire().equals(b.getPropri�taire()));
	}

	@Test
	public void testGettete_boeuf() {
		Carte a = new Carte(71); 
		Carte b = new Carte(55); 
		Carte c = new Carte(88); 
		Carte d = new Carte(45);

		
		assertTrue(a.gettete_boeuf() == 1);
		System.out.println(a.gettete_boeuf());
	
		assertTrue(b.gettete_boeuf() == 7);
		System.out.println(b.gettete_boeuf());
		
		assertTrue(c.gettete_boeuf() == 5);		
		System.out.println(c.gettete_boeuf());
		
		System.out.println(d.gettete_boeuf());
		assertTrue(d.gettete_boeuf() == 2);
	}

}
