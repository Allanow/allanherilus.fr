package MonPaquetage;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Jeu {
	private int NbJoueurs;
	private static final int NbCartes = 104;	
	private ArrayList<Serie> ListeSerie;	
	private static final int NbSeries = 4; 
	private ArrayList<Joueur> ListeJoueurs;
	private ArrayList<Carte> ListeChoixJoueurs;	
	
	public Jeu() {
		ListeJoueurs = new ArrayList<Joueur>();
		ListeSerie = new ArrayList<Serie>();
		ListeChoixJoueurs = new ArrayList<Carte>();		
	}
	
	public boolean Entre2Et10() {	//Permet de savoir si le nombre de joueur est compris entre 2 et 10.	U
		if (this.NbJoueurs<2||this.NbJoueurs>10) {
			return false;
		}
		return true;
	}	
	
	public void lecture(String nom) {	//Permet de lire un fichier		
		try {			
			Scanner in = new Scanner(new FileInputStream(nom));
			while (in.hasNextLine()) {
				Joueur j= new Joueur();
				j.setNom(in.nextLine());
				addJoueurs(j);			
			}
			setNbJoueurs(getListeJoueurs().size());
			in.close();			
		}
			catch (FileNotFoundException e) {
				System.out.println("Impossible d'ouvrir le fichier");
			}
	}	
	
	public int getNbCartes() {	//Permet d'obtenir le nombre de carte du jeu	
		return NbCartes;
	}	
	
	public int getNbSeries() {	//Permet d'obtenir le nombre de s�rie dans un jeu 
		return NbSeries;
	}
	
	public int getNbJoueurs () {	//Permet d'obtenir le nombre de joueur.	
		return this.NbJoueurs;
	}
	
	public void addJoueurs(Joueur j){ //Permet d'ajouter un joueur � la liste de joueurs.	
		this.ListeJoueurs.add(j);		
	}
	
	public void setNbJoueurs (int nbjoueur) { //Permet de modifier le nombre de joueur.	
		this.NbJoueurs = nbjoueur;		
	}
	
	public ArrayList<Joueur> getListeJoueurs(){	//Permet d'obtenir ListeJoueur	
		return ListeJoueurs;
	}	
	
	public String toStringNomJoueurs() {	//Permet d'afficher le nom de tous les joueurs 	
		 String s = "";
		 for (int i = 0; i < NbJoueurs ; i++) {
			 if (i < NbJoueurs - 2)	
				 s += ListeJoueurs.get(i).toStringNom() + ", ";
			 
			 if (i == NbJoueurs - 1) {	
				 s += " et " + ListeJoueurs.get(i).toStringNom() + ".";								 
			 }
			 if (i == NbJoueurs - 2) 
				 s += ListeJoueurs.get(i).toStringNom();
		 }		 
		 return s;		 
	}
	
	public void addSerie(Serie s) { //Permet ajouter une s�rie dans le jeu	
		this.ListeSerie.add(s);
	}
	
	public ArrayList<Serie> getListeSerie(){	//Permet d'obtenir ListeSerie	
		return ListeSerie;
	}
	
	public void addChoix (Carte c) {	//Permet d'ajouter dans ListeChoixJoueur une carte	
		this.ListeChoixJoueurs.add(c);
	}
	
	public void TrierChoix () {	//Permet de trier ListeChoixJoueur par valeur des cartes
		  Collections.sort(ListeChoixJoueurs, Carte.ComparatorValeur);
	}
	
	
	public void TrierSerie() {	//Permet de trier ListeSerie par valeur des cartes	
		Collections.sort(ListeSerie, Serie.ComparatorValeur);
	}		
	
	public String AfficherChoix() {	//Permet d'afficher les cartes dans ListeChoixJoueurs avec leur propri�taire	
		String str = "";
		for (int i = 0; i < NbJoueurs; i++) {
			str += ListeChoixJoueurs.get(i).getCarteva() + " (" + ListeChoixJoueurs.get(i).getPropri�taire() + ")";
			if (i < NbJoueurs - 2)
				str += ", ";
			else if (i == NbJoueurs - 2)
				str += " et ";
		}
		return str;
	}
	
	public void jouer() {	//Permet de jouer	
		int min_val;
		int min_idx = 0;
		int min_serie = NbCartes;
		
		for (int i = 0; i < getNbSeries() - 1; i++) {
			min_val = ListeSerie.get(i).getlastCarte().getCarteva();

			if (ListeChoixJoueurs.get(0).getCarteva() - min_val > 0) {
				min_val = ListeChoixJoueurs.get(0).getCarteva() - min_val;				
			}
			else if (min_val < min_serie ) {
				min_serie = min_val;
				min_idx = i;
			}
			else {

			}			
		}
		
		ListeSerie.get(min_idx).ajouter(ListeChoixJoueurs.get(0));
		ListeChoixJoueurs.remove(0);
		ListeSerie.get(min_idx);
		if (ListeSerie.get(min_idx).getserie().size() >= Serie.getMaxCartes()) {
			RemplacerSerie(ListeSerie.get(min_idx));
		}
	}		

	public void RemplacerSerie (Serie s) {	//Permet de remplacer une s�rie par la derni�re carte de celle-ci	
		int cpt_boeuf = 0;
		for (int i = 1; i < s.getserie().size() - 1; i++) {		
			cpt_boeuf += s.getserie().get(0).gettete_boeuf();
			s.getserie().remove(0);
			s.DecrementeNbcarte();
		}
		for (int i = 0; i < NbJoueurs; i++) {
			if (s.getserie().get(0).getPropri�taire() == ListeJoueurs.get(i).toStringNom())
				ListeJoueurs.get(i).setTeteboeuf(cpt_boeuf);
		}
		s.TrierSerie();
		
	} 

}